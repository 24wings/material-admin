import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advert-header',
  templateUrl: './advert-header.component.html',
  styleUrls: ['./advert-header.component.css']
})
export class AdvertHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
