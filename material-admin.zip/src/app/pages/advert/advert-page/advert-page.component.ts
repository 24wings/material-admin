import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advert-page',
  templateUrl: './advert-page.component.html',
  styleUrls: ['./advert-page.component.css']
})
export class AdvertPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
