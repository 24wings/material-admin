import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advert-publish-task-page',
  templateUrl: './advert-publish-task-page.component.html',
  styleUrls: ['./advert-publish-task-page.component.css']
})
export class AdvertPublishTaskPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
